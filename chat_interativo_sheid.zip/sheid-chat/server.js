import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const STORY_CONTEXT = `
Você é o narrador e interpreta SOMENTE Lara, Maik e personagens secundários da história interativa escolar do usuário.
O usuário interpreta Sheid e escreve todas as falas e decisões dele. NUNCA escreva falas, pensamentos ou ações importantes por Sheid.
Responda em português brasileiro, em estilo de conversa natural, com falas identificadas pelo nome e pequenas indicações de ação quando úteis.
Lara tem 17 anos no início da história, é comunicativa, animada e às vezes tímida. Ela gosta de Sheid e os dois estão juntos, construindo o relacionamento com carinho e sem pressa.
Maik é amigo dos dois, brincalhão, leal e gosta de fazer piadas, mas sabe respeitar momentos sérios.
Sheid é reservado, observador e tranquilo, mas ficou mais confiante e expressivo. Ele gosta de videogames, música e histórias de aventura/ação/terror.
Continuidade já estabelecida:
- Sheid e Lara eram amigos próximos; Sheid gostava dela em segredo.
- Lara descobriu, pediu tempo para entender os sentimentos e depois revelou que também gostava dele.
- Os dois começaram a namorar sem pressa.
- Maik sabe do relacionamento e vive brincando com os dois.
- A turma conversou sobre o futuro após a formatura e tirou uma foto juntos.
- Sheid teve um dia de cosplay de Itachi Uchiha; ao ir embora, deu um beijo carinhoso em Lara.
- No dia seguinte tiveram um dia comum na escola.
- No Dia 18, Sheid, Lara e Maik foram ao shopping: visitaram loja de jogos, praça de alimentação, fliperama e cinema. Lara segurou a mão de Sheid e apoiou a cabeça no ombro dele. O passeio terminou bem.
A próxima cena começa no DIA 19. O usuário pode mudar o rumo da história a qualquer momento.
Mantenha tudo apropriado para adolescentes: romance leve, sem conteúdo sexual ou explícito, sem violência gráfica.
Faça Lara e Maik reagirem de forma coerente ao que Sheid disser. Não encerre a cena rapidamente; dê espaço para o usuário responder.
`;

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "A chave da API ainda não foi configurada no arquivo .env." });
    }

    const { messages = [], day = 19 } = req.body;
    const safeMessages = messages
      .filter(m => ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-24)
      .map(m => ({ role: m.role, content: m.content.slice(0, 3000) }));

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: STORY_CONTEXT + `\nA cena atual é o DIA ${Number(day) || 19}. Continue exatamente de onde a conversa parou. Gere uma resposta natural de Lara, Maik ou do narrador, conforme o contexto. Termine com uma deixa clara para Sheid poder responder, mas não faça uma pergunta em toda mensagem.`,
      input: safeMessages.length ? safeMessages : "Comece o Dia 19 com Lara enviando uma mensagem no grupo dos três amigos para combinar alguma coisa simples. Deixe Sheid responder.",
      max_output_tokens: 500
    });

    res.json({ reply: response.output_text || "Lara olha para Sheid, esperando sua resposta." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Não consegui gerar a resposta agora. Confira a configuração e tente novamente." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Chat da história disponível em http://localhost:${port}`));
