# Chat interativo da história do Sheid

## O que este projeto faz
- Você escreve as falas e ações de Sheid.
- A IA interpreta Lara, Maik e o narrador, mantendo o contexto principal da história.
- A conversa fica salva no navegador usado.
- Você pode escolher o número do dia.

## Requisitos
- Node.js instalado.
- Uma chave de API configurada por um adulto responsável. O uso da API pode gerar custos conforme o uso.

## Como iniciar
1. Extraia o ZIP.
2. Abra a pasta `sheid-chat` em um terminal.
3. Execute `npm install`.
4. Copie `.env.example` para um arquivo chamado `.env`.
5. Coloque sua chave de API na variável `OPENAI_API_KEY` do `.env`. **Nunca coloque a chave no arquivo `public/index.html` nem compartilhe a chave.**
6. Execute `npm start`.
7. Abra `http://localhost:3000` no navegador.

A integração usa a Responses API do OpenAI no servidor. A chave fica no servidor, não no navegador.

## Observação
Este ZIP contém o site e o servidor de integração. A IA real só responderá depois de configurar uma chave de API válida. A configuração da API e eventuais custos devem ser tratados com um adulto responsável.
